import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:runaway/app/consts/textconstant.dart';

class FeedPage extends StatefulWidget {
  const FeedPage({Key? key}) : super(key: key);

  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  var itemsActionBar = [
    FloatingActionButton(
      backgroundColor: Colors.greenAccent,
      onPressed: () {},
      child: Icon(Icons.add),
    ),
    FloatingActionButton(
      backgroundColor: Colors.indigoAccent,
      onPressed: () {},
      child: Icon(Icons.camera),
    ),
    FloatingActionButton(
      backgroundColor: Colors.orangeAccent,
      onPressed: () {},
      child: Icon(Icons.card_giftcard),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color.fromRGBO(216, 250, 8, 1),
        onPressed: () {},
        tooltip: "",
        child: const Icon(
          Icons.search,
          color: Colors.black87,
        ),
      ),
      body: Stack(children: [
        Container(
            child: Center(
                child: Text(
          "Map",
          style: pageTitleStyle,
        ))),
        Positioned(
          bottom: 15,
          left: 20,
          child: ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
                padding: EdgeInsets.zero,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40))),
            child: Ink(
              decoration: BoxDecoration(
                  color: Color.fromRGBO(216, 250, 8, 1),
                  // gradient: const LinearGradient(colors: [
                  //  Color.fromRGBO(216, 250, 8, 1)
                  // ]),
                  borderRadius: BorderRadius.circular(40)),
              child: Container(
                width: 300,
                height: 60,
                alignment: Alignment.center,
                child: Text(
                  'Ride On',
                  style: pageNormalStyleGreyBig,
                ),
              ),
            ),
          ),
        ),
        // Positioned(
        //   top: 40,
        //   left: 20,
        //   child: FloatingActionButton(
        //     backgroundColor: Color.fromRGBO(216, 250, 8, 0.7),
        //     onPressed: () {},
        //     tooltip: "",
        //     child: const Icon(FontAwesomeIcons.bars),
        //   ),
        // ),
        Positioned(
          top: 40,
          left: 20,
          child: Row(
            children: [
              GestureDetector(
                onTap: () {},
                child: Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    border: Border.all(
                        color: Color.fromRGBO(216, 250, 8, 0.7), width: 3),
                    borderRadius: BorderRadius.all(Radius.circular(15.0)),
                  ),
                  child: Center(child: Icon(FontAwesomeIcons.car,color: Colors.white,)),
                ),
              ),
              SizedBox(width: 5,),
              AutoSizeText("Welcome Back \n 06 EB 7776",style: pageNormalStyle,)
            ],
          ),
        ),
      ]),
    );
  }
}
